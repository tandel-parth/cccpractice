<?php
include 'App/Code/Local/autoload.php';
include 'App/Mage.php';

Mage::init();
?>
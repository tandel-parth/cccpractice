<?php

class Catalog_Controller_Index{
    public function indexAction()
    {
        echo "Catalog_Controller";
    }
}
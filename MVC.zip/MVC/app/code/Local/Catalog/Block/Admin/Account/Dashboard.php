<?php
class Catalog_Block_Admin_Account_Dashboard extends Core_Block_Template{
public function __construct(){
    $this->setTemplate('catalog/admin/account/dashboard.phtml');
}
}
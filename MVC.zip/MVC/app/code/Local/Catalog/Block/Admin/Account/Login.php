<?php
class Catalog_Block_Admin_Account_Login extends Core_Block_Template{
    public function __construct(){
        $this->setTemplate("catalog/admin/account/login.phtml");
    }
}
?>
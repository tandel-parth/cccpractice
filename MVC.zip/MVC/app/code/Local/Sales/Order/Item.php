<?php

class Sales_Orders_Item
{

}
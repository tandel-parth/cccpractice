<?php

class Sales_Orders_Address
{

}
<?php

class Sales_Quote_Item
{

}
<?php

class Sales_Quote_Address
{

}
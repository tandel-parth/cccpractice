<?php

class Sales_Model_Sales
{

}
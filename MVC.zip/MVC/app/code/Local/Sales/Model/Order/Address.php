<?php

class Sales_Model_Order_Address
{

}
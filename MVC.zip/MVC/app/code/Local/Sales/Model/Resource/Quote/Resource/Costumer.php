<?php

class Sales_Model_Resource_Quote_Resource_Costumer extends Core_Model_Resource_Abstract
{

}
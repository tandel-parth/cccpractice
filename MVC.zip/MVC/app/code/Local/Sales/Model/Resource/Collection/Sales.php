<?php

class Sales_Model_Resource_Collection_Sales
{

}
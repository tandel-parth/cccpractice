<?php

class Sales_Model_Resource_Quote_Resource_Collection_Item extends Core_Model_Resource_Collection_Abstract
{

}
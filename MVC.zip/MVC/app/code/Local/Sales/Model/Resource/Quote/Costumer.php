<?php

class Sales_Model_Resource_Quote_Costumer extends Core_Model_Resource_Abstract
{

}
<?php

class Sales_Quote
{

}
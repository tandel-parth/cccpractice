<?php

class Cart_Controller_Checkout extends Core_Controller_Front_Action{
    
}

?>
Admin/Banner/Form
    file path = root folder>media>banner>xyz.jpg
    
Admin/Banner/list